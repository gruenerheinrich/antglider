

Installation Hints
==================

1) Copy the antglider.jar to your ant/lib dir.

2) Copy the antglider.bat to your ant/bin dir.

3) call antglider.bat

4) Optional call antglider.bar -configfile yourconfig.xml

5) Enjoy.



centauron.de
info@centauron.de
